
  precision highp float;
  varying vec2 v_uv;
  uniform sampler2D u_base;
  uniform sampler2D u_effect;
  uniform int u_blend;
  uniform float u_opacity;

  vec3 straightColor(vec4 p) {
    return p.a > 0.00001 ? p.rgb / p.a : vec3(0.0);
  }

  void main() {
    vec4 basePixel = texture2D(u_base, v_uv);
    vec4 effectPixel = texture2D(u_effect, v_uv);
    vec3 baseColor = straightColor(basePixel);
    vec3 effectColor = straightColor(effectPixel);
    vec3 blended = effectColor;
    if (u_blend == 1) {
      blended = baseColor + effectColor;
    } else if (u_blend == 2) {
      blended = baseColor * effectColor;
    } else if (u_blend == 3) {
      blended = vec3(1.0) - (vec3(1.0) - baseColor) * (vec3(1.0) - effectColor);
    } else if (u_blend == 4) {
      blended = mix(
        2.0 * baseColor * effectColor,
        vec3(1.0) - 2.0 * (vec3(1.0) - baseColor) * (vec3(1.0) - effectColor),
        step(vec3(0.5), baseColor)
      );
    } else if (u_blend == 5) {
      blended = min(baseColor, effectColor);
    } else if (u_blend == 6) {
      blended = max(baseColor, effectColor);
    } else if (u_blend == 7) {
      blended = min(vec3(1.0), baseColor / max(vec3(1.0) - effectColor, vec3(0.0039215686)));
    }

    float effectAlpha = effectPixel.a * clamp(u_opacity, 0.0, 1.0);
    float invEffectAlpha = 1.0 - effectAlpha;
    float outputAlpha = effectAlpha + (basePixel.a * invEffectAlpha);
    vec3 compositedColor = mix(effectColor, blended, basePixel.a);
    vec3 outputColor = (basePixel.rgb * invEffectAlpha) + (compositedColor * effectAlpha);
    gl_FragColor = vec4(clamp(outputColor, 0.0, 1.0), outputAlpha);
  }
