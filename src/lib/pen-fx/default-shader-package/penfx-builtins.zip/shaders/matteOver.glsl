
  precision highp float;
  varying vec2 v_uv;
  uniform sampler2D u_base;
  uniform sampler2D u_source;
  uniform sampler2D u_matte;
  uniform int u_mode;

  vec3 straightColor(vec4 p) {
    return p.a > 0.00001 ? p.rgb / p.a : vec3(0.0);
  }

  void main() {
    vec4 basePixel = texture2D(u_base, v_uv);
    vec4 sourcePixel = texture2D(u_source, v_uv);
    vec4 mattePixel = texture2D(u_matte, v_uv);
    float matteValue = mattePixel.a;
    if (u_mode == 1 || u_mode == 3) {
      matteValue = dot(straightColor(mattePixel), vec3(0.2126, 0.7152, 0.0722)) * mattePixel.a;
    }
    if (u_mode >= 2) matteValue = 1.0 - matteValue;
    vec4 maskedSource = sourcePixel * clamp(matteValue, 0.0, 1.0);
    float inverseAlpha = 1.0 - maskedSource.a;
    gl_FragColor = vec4(
      maskedSource.rgb + (basePixel.rgb * inverseAlpha),
      maskedSource.a + (basePixel.a * inverseAlpha)
    );
  }
